$(function(){
    $('#t1').clockface();  
});