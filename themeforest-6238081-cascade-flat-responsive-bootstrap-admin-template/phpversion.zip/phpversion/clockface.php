<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Test Clockface</title>

	<!-- clockface -->
	<link rel="stylesheet" href="../css/clockface.css" type="text/css"/>
	<script src="../js/clockface.js"></script>
	<script src="../js/jquery.clockface.js"></script>
</head>
<body>
	
	<input type="text" id="t1" value="2:30 PM" data-format="hh:mm A" class="input-small">

	
	<!-- this test for parsing string to time, takes about 6 sec, can be skipped -->
	<!-- // <script src="parse.js"></script> -->
</body>
</html>